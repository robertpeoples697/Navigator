
// Mobile nav toggle
const navToggle = document.querySelector('.nav-toggle');
const navMenu = document.getElementById('nav-menu');
if (navToggle && navMenu) {
  navToggle.addEventListener('click', () => {
    const isOpen = navMenu.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
  });
}

// Simple client-side form enhancement (no backend required for Netlify set-up)
const form = document.querySelector('form[name="contact"]');
if (form) {
  form.addEventListener('submit', (e) => {
    // Netlify will handle it if deployed there; show a friendly message otherwise.
    if (!location.hostname.includes('netlify.app')) {
      e.preventDefault();
      alert('Thanks for your message! If you deploy on Netlify, this form will submit automatically. For now, email us directly.');
    }
  });
}
